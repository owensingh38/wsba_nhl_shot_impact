from nst_scraper import NSTBioScrape
from nst_scraper import NSTSkaterScrape
from nst_scraper import NSTTeamScrape