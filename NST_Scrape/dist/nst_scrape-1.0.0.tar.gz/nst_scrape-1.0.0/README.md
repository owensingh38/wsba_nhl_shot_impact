# NST_Scrape

NST_Scrape is a Python Package for scraping National Hockey League information and stats from Natural Stat Trick.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install NST_Scrape.

```bash
pip install NST_scrape
```

## Usage

